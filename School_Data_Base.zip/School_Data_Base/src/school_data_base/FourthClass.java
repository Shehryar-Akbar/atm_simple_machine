/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package school_data_base;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Shehryar Akbar
 */
public class FourthClass implements ActionListener{
     private JFrame frame;
    private JPanel panel1, panel2, panel3, panel4;
    private JLabel label1, label2, label3, label4, label5,label6;
    private JTextField field1,field2,field3,field4,field5,field6;
    private JButton btn1,btn2,btn3;
    private Connection con;
    DefaultTableModel model = new DefaultTableModel();
    JTable jtbl = new JTable(model);
    
    static final String host = "jdbc:derby://localhost:1527/Management_System";
    static final String uName = "student";
    static final String uPass = "student";
    
    public void fourthclass() {
        
        try{
             con = DriverManager.getConnection(host, uName, uPass);
            System.out.println("connection succeeded");
        
            
        frame = new JFrame("School Management System");
        frame.setSize(550,500);
        frame.setLayout(new BorderLayout(5,5));
        frame.setLocationRelativeTo(null );
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     
//============> for the labels in the WEST border area. 
        panel1 = new JPanel();
        panel1.setLayout(new GridLayout(6,1));
        
        JPanel p1 = new JPanel();
        label1 = new JLabel("      ID: ");
        p1.add(label1);
        JPanel p2 = new JPanel();
        label2 = new JLabel("      Name: ");
        p2.add(label2);
        JPanel p3 = new JPanel();
        label3 = new JLabel("      F/Name: ");
        p3.add(label3);
        JPanel p4 = new JPanel();
        label4 = new JLabel("      Address: ");
        p4.add(label4);
        JPanel p5 = new JPanel();
        label5 = new JLabel("      Phone: ");
        p5.add(label5);
        JPanel p6 = new JPanel();
        label6 = new JLabel("update ID: ");
        p6.add(label6);
        
        
        panel1.add(p1);
        panel1.add(p2);
        panel1.add(p3);
        panel1.add(p4);
        panel1.add(p5);
        panel1.add(p6);
 //=============> for the testfields in the center.
        panel2 = new JPanel();
        panel2.setLayout(new GridLayout(6,1));
        JPanel p12 = new JPanel();
        JPanel p7 = new JPanel();
        field1 = new JTextField(35);
        p12.add(field1);
        JPanel p8 = new JPanel();
        field2 = new JTextField(35);
        p7.add(field2);
        JPanel p9 = new JPanel();
        field3 = new JTextField(35);
        p8.add(field3);
        JPanel p10 = new JPanel();
        field4 = new JTextField(35);
        p9.add(field4);
        field5 = new JTextField(35);
        p10.add(field5);
        JPanel p11 = new JPanel();
        field6 = new JTextField(35);
        p11.add(field6);
        
        
        panel2.add(p12);
        panel2.add(p7);
        panel2.add(p8);
        panel2.add(p9);
        panel2.add(p10);
        panel2.add(p11);
 //===========> for the logo IN THE NORTH
        panel3 = new JPanel();
        JPanel panel5 = new JPanel();
        panel5.setLayout(new GridLayout(3,1));
        JLabel label7 = new JLabel("Note: just enter Student ID for deleting record");
        JLabel label8 = new JLabel("Note: enter the student ID in update ID field if you want to update a record");
        JLabel label9 = new JLabel("One thing more is that try to fill the update ID field with 0 just for the smoth flow of the program. ");
        panel5.add(label7);
        panel5.add(label8);
        panel5.add(label9);
        panel3.add(panel5);
 //==================> for the buttons in the SOUTH.
 
        btn1 = new JButton("Add Rec");
        btn1.setFocusable(false);
        btn1.addActionListener(this);
        
        btn2 = new JButton("Delete Rec");
        btn2.setFocusable(false);
        btn2.addActionListener(this);
        
        btn3 = new JButton("Update");
        btn3.setFocusable(false);
        btn3.addActionListener(this);
        
        panel4 = new JPanel();
        panel4.add(btn1);
        panel4.add(btn2);
        panel4.add(btn3);
        
//=========================> for the frame visibility.        
        frame.add(panel1, BorderLayout.WEST);
        frame.add(panel2, BorderLayout.CENTER);
        frame.add(panel3, BorderLayout.NORTH);
        frame.add(panel4, BorderLayout.SOUTH);
//        frame.add(panel5, BorderLayout.EAST);
       
        frame.setVisible(true);
        }
        
        catch(Exception e){
            System.out.println(e);
        }
        
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        String s1 = field1.getText();
        int id = Integer.parseInt(s1);
        String s2 = field2.getText();
        String s3 = field3.getText();
        String s4 = field4.getText();
        String s5 = field5.getText();
        
        
        if(ae.getSource() == btn1){
           
            try {
                PreparedStatement stmt1 = con.prepareStatement("INSERT INTO STUDENT.FOURTHCLASS(ID, NAME,F_NAME,ADDRESS,PHONE)VALUES(?,?,?,?,?)");
                stmt1.setInt(1, id);
                stmt1.setString(2, s2);
                stmt1.setString(3, s3);
                stmt1.setString(4, s4);
                stmt1.setString(5, s5);
                stmt1.executeUpdate();  
                JOptionPane.showMessageDialog(btn1, "Student added");
            } catch (SQLException ex) {
                System.out.println(ex);
            }
        }
        if(ae.getSource() == btn2){
            try {
                PreparedStatement stmt2 = con.prepareStatement("DELETE FROM STUDENT.FOURTHCLASS WHERE ID = ?");
                stmt2.setInt(1, id);
                stmt2.executeUpdate();
                JOptionPane.showMessageDialog(btn2, "Record Deleted");
            } catch (SQLException ex) {
                Logger.getLogger(Nursery.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        if(ae.getSource() == btn3){
            
            String s6 = field6.getText();
            int Update = Integer.parseInt(s6);
            try {
                PreparedStatement stmt3 = con.prepareStatement("UPDATE STUDENT.FOURTHCLASS SET ID= ?, NAME= ?, F_NAME= ?, ADDRESS= ?, PHONE= ? WHERE ID = ?");
                stmt3.setInt(1, id);
                stmt3.setString(2, s2);
                stmt3.setString(3, s3);
                stmt3.setString(4, s4);
                stmt3.setString(5, s5);
                stmt3.setInt(6, Update);
                stmt3.executeUpdate();  
                JOptionPane.showMessageDialog(btn3, "Record updated");
            } catch (SQLException ex) {
                Logger.getLogger(Nursery.class.getName()).log(Level.SEVERE, null, ex);
            }
        }      
    }   
}
