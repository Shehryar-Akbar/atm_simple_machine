package school_data_base;

//import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.Border;

public class ClassesDetails implements ActionListener{
    
    private JFrame frame;
    private JPanel panel1,panel2,panel3;
    private JLabel label1,label2;
    private JComboBox comboBox;
    private JButton button1, button2;
    
    public void SelectOneOfit(){
        frame = new JFrame("School Management System");
        frame.setSize(400,350);
        frame.setLayout(new GridLayout(3,1));
        frame.setLocationRelativeTo(null );
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      // ================> for the first row 
        panel1 = new JPanel();
        ImageIcon icon;
        icon = new ImageIcon("Star2.PNG");
        label1 = new JLabel("Star Private School");
        label1.setHorizontalTextPosition(JLabel.CENTER);
        label1.setVerticalTextPosition(JLabel.BOTTOM);
        panel1.setLayout(new FlowLayout(FlowLayout.CENTER,5,6));
        label1 = new JLabel(icon);
        panel1.add(label1);
      //===================> for the second row
        JPanel pan = new JPanel();
        panel2 = new JPanel();
        panel2.setLayout(new GridLayout(2,1));
        label2 = new JLabel();
        label2.setText("Star Private School");
        pan.add(label2);
        panel2.add(pan);
        Border border = BorderFactory.createTitledBorder("Select a class please");
        String list[] = { "Nursary", "K.G", "1st", "2nd","3rd","4th","5th"};
        comboBox = new JComboBox(list);
        panel2.setBorder(border);
        panel2.add(comboBox);
        
    //=============> for the third row
        panel3 = new JPanel();
        button1 = new JButton("OK");
        button1.setFocusable(false);
        button1.addActionListener(this);
        button2 = new JButton("Cancel");
        button2.setFocusable(false);
        button2.addActionListener(this);
        panel3.add(button1);
        panel3.add(button2);
        
    //==============> adding panels to the frame.
        frame.add(panel1);
        frame.add(panel2);
        frame.add(panel3);
         
        frame.setVisible(true);
        
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
       if(ae.getSource() == button1){
        //=============> for combobox 
        //=============> 0,1,2,3 are for the indexces... 
            if(comboBox.getSelectedIndex() == 0){
                Nursery obj = new Nursery();
                obj.nursery();
            }
            else if(comboBox.getSelectedIndex() == 1){
                KG obj = new KG();
                obj.KG_class();
            }
            else if(comboBox.getSelectedIndex() == 2){
                FirstClass obj = new FirstClass();
                obj.firstclass();
            }
            else if(comboBox.getSelectedIndex() == 3){
                SecondClass obj = new SecondClass();
                obj.secondclass();
            }
            else if(comboBox.getSelectedIndex() == 4){
                FourthClass obj = new FourthClass();
                obj.fourthclass();
            }
            else if(comboBox.getSelectedIndex() == 5){
                FifthClass obj = new FifthClass();
                obj.fifthclass();
            }
        }
        if(ae.getSource() == button2){
            frame.dispose();
        }
    }
}
