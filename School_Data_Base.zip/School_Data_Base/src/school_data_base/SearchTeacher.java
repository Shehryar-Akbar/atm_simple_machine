/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package school_data_base;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Shehryar Akbar
 */
public class SearchTeacher implements ActionListener{
     private JFrame frame;
    private JPanel panel1,panel2,panel3,panel4;
    private JButton btn1,btn2;
    private JLabel label1,label3,label4;
    private JTextField field2;
    private Connection con;
    public void TeacherSearch(){
        
        final String host = "jdbc:derby://localhost:1527/Management_System";
        final String uName = "student";
        final String uPass = "student";

        try {
            con = DriverManager.getConnection(host, uName, uPass);
            System.out.println("connection succeeded");
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        frame = new JFrame("School Management System");
        frame.setSize(400,400);
        frame.setLayout(new GridLayout(3,1));
        frame.setLocationRelativeTo(null );
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       //========================> for the first row in which two labels are given 
        panel1= new JPanel();
        label1 = new JLabel("Enter the Class and ID of the student to search");
        label4 = new JLabel("Note: the class should be in capital latters");
        panel1.add(label1);
        panel1.add(label4);
       //======================> for the second row in which textfields and labels are given
        panel2 = new JPanel();
        panel2.setLayout(new GridLayout(2,1));
        JPanel p2 = new JPanel();
        label3 = new JLabel("ID:         ");
        field2 = new JTextField(15);
        p2.add(label3);
        p2.add(field2);
        panel2.add(p2);
      //============> for the third row in which buttons are located.
        
        btn1 = new JButton("Search");
        btn1.setFocusable(false);
        btn1.addActionListener(this);
        
        btn2 = new JButton("Close");
        btn2.setFocusable(false);
        btn2.addActionListener(this);
        
        panel3 = new JPanel();
        panel3.add(btn1);
        panel3.add(btn2);
      //===========================> FOR THE FRAM VISIBILITY.
        frame.add(panel1);
        frame.add(panel2);
        frame.add(panel3);
        frame.setVisible(true);
        
        
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        
        String s2 = field2.getText();
        int id = Integer.parseInt(s2);
        
       if(ae.getSource() == btn1){
            try {
                    String stmt = "SELECT FROM STUDENT.TEACHER WHERE ID = "+id;                   
                    PreparedStatement stmt1 = con.prepareStatement(stmt);
                    ResultSet rs = stmt1.executeQuery();

                    String str = (rs.getInt("ID")+" "+rs.getString("NAME")+" "+rs.getString("F_NAME")+" "+rs.getString("PHONE")+" "+rs.getString("SALARY"));
                    JOptionPane.showMessageDialog(btn1,str);
                
            } catch (SQLException ex) {
                Logger.getLogger(StudentSearch.class.getName()).log(Level.SEVERE, null, ex);
            }
       }
    }
}
