package school_data_base;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.Border;
public class MainMenu implements ActionListener{

    private JFrame f;
    private JPanel p,p1, p2;
    private JButton button1, button2;
    private JComboBox comboBox;
    private ImageIcon icon;
    private JLabel l,label2;
    
    public void display(){
        
        f = new JFrame("School Management System");
        f.setSize(400,350);
        f.setLayout(new GridLayout(3,1));
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
 //=========> for the pic int the frame.
        p = new JPanel();
        icon = new ImageIcon("Star2.PNG");
        p.setLayout(new FlowLayout(FlowLayout.CENTER,5,6));
        l = new JLabel(icon);
        p.add(l);
        
        
 //==========> for the combobox.
        JPanel pan = new JPanel();
        p1 = new JPanel();
        p1.setLayout(new GridLayout(2,1));
        label2 = new JLabel();
        label2.setText("Star Private School");
        pan.add(label2);
        p1.add(pan);
        Border border = BorderFactory.createTitledBorder("Select one of these");
        String list[] = { "Teachers", "Class", "Search Record"};
        comboBox = new JComboBox(list);
        p1.setBorder(border);
        p1.add(comboBox);
        
//==========> for the button.
        p2 = new JPanel();
        button1 = new JButton("OK");
        button1.setFocusable(false);
        button1.addActionListener(this);
        button2 = new JButton("Cancel");
        button2.setFocusable(false);
        button2.addActionListener(this);
        p2.add(button1);
        p2.add(button2);
// =============> Adding panels to the frame.    
        f.add(p);
        f.add(p1);
        f.add(p2);
        
        f.setVisible(true);
        f.setLocationRelativeTo(null);
        
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        //=============> for the button
        if(ae.getSource() == button1){
        //=============> for combobox 
        //=============> 0,1,2,3 are for the indexces... 
            if(comboBox.getSelectedIndex() == 0){
                
                Teachers obj = new Teachers();
                obj.TeacherData();
            }
            else if(comboBox.getSelectedIndex() == 1){
                ClassesDetails obj = new ClassesDetails();
                obj.SelectOneOfit();
                
            }
            else if(comboBox.getSelectedIndex() == 2){
                SearchRecord obj = new SearchRecord();
                obj.search();
            }
               
        }
        if(ae.getSource() == button2){
            f.dispose();
        }
    } 
}
